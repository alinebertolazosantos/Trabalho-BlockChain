#include "Blockchain.h"

int main() {
  Blockchain BlockChain;

  while (true) {
    cout << "    Menu de Opções " << endl;
    cout << "1 - Transferindo Dinheiro" << endl;
    cout << "2 - Ver Dados de um Bloco" << endl;
    cout << "3 - Veja o Blockchain" << endl;
    cout << "4 - Feche o programa" << endl;
    cout << endl << "Escolha uma opção:" << endl;
    char Ans;
    cin >> Ans;
    if (Ans == '1') {
      string SenderKey, ReceiverKey;
      double Amount;
      int Diff;
      cout << "Digite a Chave do Remetente:" << endl;
      cin >> SenderKey;
      cout << "Digite a Chave do Receptor :" << endl;
      cin >> ReceiverKey;
      cout << "Digite o valor:" << endl;
      cin >> Amount;
      cout << "Digite sua dificuldade ou zero para ignorar:" << endl;
      cin >> Diff;

      Transaction T1(SenderKey, ReceiverKey, Amount);

      if (Diff == 0) {
        Block block(
            T1,
            BlockChain.get_BlockChain()[BlockChain.get_BlockChain().size() - 1]
                .get_CurrentHash(),
            BlockChain.get_BlockChain().size());

        BlockChain.AddBlock(block);

        BlockChain.CheckHash(block.get_index() - 1, block.get_PrevHash());
      } else {
        Block block(
            T1,
            BlockChain.get_BlockChain()[BlockChain.get_BlockChain().size() - 1]
                .get_CurrentHash(),
            BlockChain.get_BlockChain().size(), Diff);

        BlockChain.AddBlock(block);

        BlockChain.CheckHash(block.get_index() - 1, block.get_PrevHash());
      }
    } else {
      switch (Ans) {
      case '2':
        cout << "Digite seu índice:" << endl;
        int index;
        cin >> index;
        if (index > BlockChain.get_BlockChain().size() || index < 1) {
          cout << "\n====== Não há nenhum bloco com o indice indicado! ======\n"
               << endl;
        } else {
          BlockChain.ShowBlock(index - 1);
        }
        break;
      case '3':
        cout << "AlineIsadora" << endl;
        break;
      case '4':
        BlockChain.ShowBlockchain();
        break;
      default:
        cout << "Escolha Errada! Tente novamente" << endl;
        break;
      }
    }
  }
}